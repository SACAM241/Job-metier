Config                      = {}
Config.DrawDistance         = 100.0
Config.BankSavingPercentage = 2.5
Config.Locale = 'fr'

Config.Zones = {

	BankActions = {
		Pos   = { x = 260.130, y = 204.308, z = 109.287 },
		Size  = { x = 1.5, y = 1.5, z = 1.0 },
		Color = { r = 102, g = 102, b = 204 },
		Type  = 1
	}

}
