Locales['en'] = {
  -- regulars
  	['duty'] = 'Appuyez sur ~INPUT_CONTEXT~ pour ~g~prendre~s~/~r~quitté~s~ votre service',
	['onduty'] = 'Tu as pris ton service',
	['offduty'] = 'Tu as quitté ton service',
	['notpol'] = 'Vous n\'êtes pas un policier.',
	['notamb'] = 'Vous n\'êtes pas un ambulancier.',
}
