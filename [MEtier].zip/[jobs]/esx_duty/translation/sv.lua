Locales['sv'] = {
  -- vanliga
  	['duty'] = 'Tryck ~INPUT_CONTEXT~ för att gå ~g~in~s~/~r~ur~s~ tjänst',
	['onduty'] = 'Du gick in i tjänst.',
	['offduty'] = 'Du gick ur tjänst.',
	['notpol'] = 'Du är ej inom poliskåren.',
	['notamb'] = 'Du är ej inom sjukvården.',
}
