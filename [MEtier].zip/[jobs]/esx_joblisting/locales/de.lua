Locales['de'] = {

	['new_job'] = 'Du hast einen neuen Job!',
	['access_job_center'] = 'Drücke ~INPUT_PICKUP~ um das ~b~Arbeitsamt~s~ zu öffnen.',
	['job_center'] = 'Arbeitsamt',

}
