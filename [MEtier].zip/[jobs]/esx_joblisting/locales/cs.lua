Locales['cs'] = {

	['new_job'] = 'máte novou práci!',
	['access_job_center'] = 'zmáčkněte ~INPUT_PICKUP~ pro přístup na ~b~Úřad práce~s~.',
	['job_center'] = 'úřad práce',

}
