Config              = {}
Config.DrawDistance = 100.0
-- Config.ZoneSize     = {x = 3.0, y = 3.0, z = 2.0}
-- Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 1
Config.Locale = 'fr'

Config.Zones = {
	{x = -265.036, y = -963.630, z = 30.223}
}

---------------------------------
--- Copyright by ikNox#6088 ---
---------------------------------