commands

/cam to get your camera out and put it back away
press e when it is out to activate it
backspace get out of the view finder

/mic to get a microphone out and put it away
you can point to direct it

/bmic to toggle the Boom Mic

Based off https://github.com/xander1998/saw by xlander1998
with permission to publish

and with code from https://github.com/ZAUB1/ESX-Binoculars by ZAUB1
