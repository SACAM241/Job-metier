# esx_statejob-master
import sql
copy the folder in your resource
.config put your language
start esx_statejob
restart the server
enjoy to use
